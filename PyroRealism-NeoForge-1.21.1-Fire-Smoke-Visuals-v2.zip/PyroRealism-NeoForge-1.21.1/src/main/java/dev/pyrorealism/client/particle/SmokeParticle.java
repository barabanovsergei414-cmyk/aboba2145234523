package dev.pyrorealism.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

public final class SmokeParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final boolean dark;
    private final float baseSize;
    private final double phase;

    public SmokeParticle(ClientLevel level, double x, double y, double z,
                         double xSpeed, double ySpeed, double zSpeed,
                         SpriteSet sprites, boolean dark) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.sprites = sprites;
        this.dark = dark;
        this.phase = this.random.nextDouble() * Math.PI * 2.0;
        // Smaller, irregular billows prevent the old oversized "stacked balls" look.
        this.baseSize = (dark ? 0.115F : 0.14F) + this.random.nextFloat() * (dark ? 0.075F : 0.095F);
        this.quadSize = baseSize;
        this.lifetime = (dark ? 190 : 260) + this.random.nextInt(dark ? 55 : 80);
        this.gravity = -0.018F;
        this.friction = 0.96F;
        this.hasPhysics = false;
        this.xd = xSpeed;
        this.yd = ySpeed + (dark ? 0.035 : 0.043);
        this.zd = zSpeed;
        this.alpha = dark ? 0.58F : 0.40F;
        this.setSpriteFromAge(sprites);
        if (dark) {
            this.setColor(0.20F, 0.205F, 0.22F);
        } else {
            this.setColor(0.43F, 0.44F, 0.46F);
        }
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;

        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }

        float progress = this.age / (float) this.lifetime;
        double t = this.age * (dark ? 0.072 : 0.055) + phase;
        double eddy = dark ? 0.0021 : 0.0030;
        this.xd += Math.sin(t) * eddy + Math.sin(t * 0.43 + phase) * eddy * 0.55;
        this.zd += Math.cos(t * 0.91) * eddy + Math.cos(t * 0.37 + phase) * eddy * 0.55;
        this.yd = Math.min(this.yd + 0.00030, dark ? 0.047 : 0.060);

        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.991;
        this.yd *= 0.998;
        this.zd *= 0.991;

        float growth = 0.90F + progress * (dark ? 1.10F : 1.35F);
        this.quadSize = baseSize * growth;

        float fadeIn = Math.min(1.0F, this.age / 12.0F);
        float fadeOut = Math.min(1.0F, (this.lifetime - this.age) / (dark ? 26.0F : 38.0F));
        this.alpha = (dark ? 0.47F : 0.32F) * fadeIn * Math.max(0.0F, fadeOut);

        if (dark) {
            float sootFade = Math.min(1.0F, progress * 1.2F);
            float shade = 0.16F + sootFade * 0.13F;
            this.setColor(shade, shade * 1.02F, shade * 1.08F);
        } else {
            float warmth = 1.0F - progress;
            float gray = 0.43F + progress * 0.17F;
            this.setColor(gray + warmth * 0.025F, gray + warmth * 0.018F, gray);
        }
        this.setSpriteFromAge(this.sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getLightColor(float partialTick) {
        return super.getLightColor(partialTick);
    }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final boolean dark;

        public Provider(SpriteSet sprites, boolean dark) {
            this.sprites = sprites;
            this.dark = dark;
        }

        @Override
        public SmokeParticle createParticle(SimpleParticleType type, ClientLevel level,
                                           double x, double y, double z,
                                           double xSpeed, double ySpeed, double zSpeed) {
            return new SmokeParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, sprites, dark);
        }
    }
}
